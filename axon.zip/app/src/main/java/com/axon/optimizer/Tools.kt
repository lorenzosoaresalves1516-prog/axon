package com.axon.optimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.io.File

data class Stats(val ramUsed: Long, val ramTotal: Long, val stoUsed: Long, val stoTotal: Long, val temp: Float)

fun readStats(ctx: Context): Stats {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    val st = StatFs(Environment.getDataDirectory().path)
    val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val t = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    return Stats(mi.totalMem - mi.availMem, mi.totalMem, st.totalBytes - st.availableBytes, st.totalBytes, t)
}

fun fmt(b: Long): String = when {
    b >= (1L shl 30) -> "%.1f GB".format(b / 1073741824.0)
    b >= (1L shl 20) -> "%d MB".format(b shr 20)
    b >= 1024 -> "%d KB".format(b shr 10)
    else -> "$b B"
}

data class FileItem(val file: File, val size: Long, val kind: String)

object Cleaner {
    private val tempExt = setOf("tmp", "temp", "log", "bak", "old", "dmp", "crdownload", "part", "chk")
    private val personal = setOf("DCIM", "Pictures", "Music", "Documents", "Movies", "Recordings")

    fun scan(): List<FileItem> {
        val root = Environment.getExternalStorageDirectory()
        val now = System.currentTimeMillis()
        val out = ArrayList<FileItem>()
        root.walkTopDown()
            .onEnter { !(it.parentFile == root && it.name == "Android") }
            .forEach { f ->
                if (!f.isFile) return@forEach
                val size = f.length()
                val ext = f.extension.lowercase()
                val top = f.relativeTo(root).path.substringBefore('/')
                val kind: String? = when {
                    ext == "apk" -> "APK"
                    ext in tempExt || "/.thumbnails/" in f.path || "/.cache/" in f.path -> "Temp"
                    size > (100L shl 20) -> "Grande"
                    size > (5L shl 20) && top !in personal && now - f.lastModified() > 180L * 86400000L -> "Sem uso"
                    else -> null
                }
                if (kind != null) out.add(FileItem(f, size, kind))
            }
        return out.sortedByDescending { it.size }.take(600)
    }
}

data class Bloat(val name: String, val pkg: String, val safe: Boolean, val desc: String)

object Bloats {
    val list = listOf(
        Bloat("MSA (anúncios)", "com.miui.msa.global", true, "Anúncios personalizados do sistema"),
        Bloat("Analytics", "com.miui.analytics", true, "Coleta de dados de uso"),
        Bloat("GetApps", "com.xiaomi.mipicks", true, "Loja com sugestões de apps"),
        Bloat("Relatório de bugs", "com.miui.bugreport", true, "Envio de erros à Xiaomi"),
        Bloat("Mi Browser", "com.mi.globalbrowser", true, "Navegador com anúncios"),
        Bloat("Mi Vídeo", "com.miui.videoplayer", true, "Player com recomendações"),
        Bloat("Mi Música", "com.miui.player", true, "Player da Xiaomi"),
        Bloat("Games (Xiaomi)", "com.xiaomi.glgm", true, "Central de jogos"),
        Bloat("Wallpaper Carousel", "com.miui.android.fashiongallery", true, "Papéis de parede com anúncios"),
        Bloat("ShareMe", "com.xiaomi.midrop", true, "Transferência de arquivos"),
        Bloat("Mi Mover", "com.miui.huanji", true, "Migração de dados"),
        Bloat("Serviços e feedback", "com.miui.miservice", true, "Suporte da Xiaomi"),
        Bloat("Facebook App Manager", "com.facebook.appmanager", true, "Serviço pré-instalado"),
        Bloat("Facebook Services", "com.facebook.services", true, "Serviço pré-instalado"),
        Bloat("Facebook System", "com.facebook.system", true, "Serviço pré-instalado"),
        Bloat("Netflix Activation", "com.netflix.partner.activation", true, "Ativação de parceiro"),
        Bloat("Yellow Pages", "com.miui.yellowpage", false, "Identificador de chamadas"),
        Bloat("Quick Apps", "com.miui.hybrid", false, "Apps instantâneos"),
        Bloat("App Vault", "com.mi.android.globalminusscreen", false, "Tela à esquerda do launcher"),
        Bloat("Mi Cloud", "com.miui.cloudservice", false, "Sincronização de nuvem"),
        Bloat("Mi Cloud Backup", "com.miui.cloudbackup", false, "Backup na nuvem"),
        Bloat("Discover", "com.xiaomi.discover", false, "Atualizador de apps do sistema")
    )
}

fun isInstalled(pm: PackageManager, pkg: String): Boolean =
    try { pm.getApplicationInfo(pkg, 0); true } catch (e: Exception) { false }
