package com.axon.optimizer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

val Bg = Color(0xFF07090C)
val Card = Color(0xFF10151B)
val Line = Color(0xFF1D2630)
val Yellow = Color(0xFFFFD60A)
val Cyan = Color(0xFF22E1FF)
val Mute = Color(0xFF7D8B9A)
val Red = Color(0xFFFF5D6C)
val Green = Color(0xFF3DDC97)
val Txt = Color(0xFFE8EEF5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Yellow, onPrimary = Color.Black,
                    background = Bg, onBackground = Txt, surface = Card, onSurface = Txt
                )
            ) { Root() }
        }
    }
}

/* ---------- componentes base ---------- */

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp)).background(Card)
            .border(1.dp, Line, RoundedCornerShape(18.dp)).padding(16.dp),
        content = content
    )
}

@Composable
fun Btn(text: String, enabled: Boolean = true, ghost: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (ghost) Line else Yellow,
            contentColor = if (ghost) Txt else Color.Black,
            disabledContainerColor = Line, disabledContentColor = Mute
        )
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp) }
}

@Composable
fun Chip(t: String, on: Boolean, click: () -> Unit) {
    Text(
        t, color = if (on) Color.Black else Mute, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (on) Yellow else Card).clickable { click() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun CheckRow(
    title: String, sub: String, right: String, checked: Boolean,
    tag: String? = null, tagColor: Color = Green, onToggle: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card)
            .clickable { onToggle() }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked, onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(checkedColor = Yellow, checkmarkColor = Color.Black)
        )
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                if (tag != null) Text("  $tag", color = tagColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Text(sub, color = Mute, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (right.isNotEmpty()) Text(right, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp))
    }
}

@Composable
fun SwitchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            Text(sub, color = Mute, fontSize = 11.sp)
        }
        Switch(
            checked = on, onCheckedChange = change,
            colors = SwitchDefaults.colors(checkedTrackColor = Yellow, checkedThumbColor = Color.Black)
        )
    }
}

@Composable
fun Header() {
    Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Card)
                .border(1.5.dp, Yellow, RoundedCornerShape(11.dp)),
            contentAlignment = Alignment.Center
        ) { Text("A", color = Yellow, fontWeight = FontWeight.Black, fontSize = 20.sp) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("AXON", fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Text("OTIMIZADOR PARA POCO", color = Mute, fontSize = 9.sp, letterSpacing = 2.sp)
        }
    }
}

fun openAllFiles(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")))
    } catch (e: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
    }
}

fun openShizuku(ctx: Context) {
    val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (i != null) ctx.startActivity(i)
    else {
        Toast.makeText(ctx, "Shizuku não instalado", Toast.LENGTH_LONG).show()
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
    }
}

@Composable
fun SetupCard(ready: Boolean, allFiles: Boolean) {
    val ctx = LocalContext.current
    if (ready && allFiles) return
    Box(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Panel {
            Text("CONFIGURAÇÃO", color = Mute, fontSize = 11.sp, letterSpacing = 2.sp)
            if (!allFiles) {
                Spacer(Modifier.height(8.dp))
                Text("Acesso a todos os arquivos (necessário para a limpeza).", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Btn("PERMITIR ARQUIVOS", ghost = true) { openAllFiles(ctx) }
            }
            if (!ready) {
                val on = Shell.available()
                Spacer(Modifier.height(8.dp))
                Text(
                    if (!on) "Shizuku inativo. Instale, inicie por Depuração sem fio e volte aqui."
                    else "Conceda a permissão do Shizuku ao AXON.", fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))
                Btn(if (!on) "ABRIR SHIZUKU" else "CONCEDER PERMISSÃO", ghost = true) {
                    if (!on) openShizuku(ctx) else Shell.request()
                }
            }
        }
    }
}

/* ---------- raiz ---------- */

@Composable
fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    var ready by remember { mutableStateOf(false) }
    var allFiles by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            ready = Shell.available() && Shell.granted()
            allFiles = Environment.isExternalStorageManager()
            delay(1500)
        }
    }
    val tabs = listOf("Início" to "◉", "Limpeza" to "✦", "Debloat" to "⌫", "Games" to "▶")
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Color(0xFF0A0E12)) {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(
                    selected = tab == i, onClick = { tab = i },
                    icon = { Text(t.second, fontSize = 20.sp) },
                    label = { Text(t.first, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Yellow, selectedTextColor = Yellow, indicatorColor = Line,
                        unselectedIconColor = Mute, unselectedTextColor = Mute
                    )
                )
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Header()
            SetupCard(ready, allFiles)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Home(ready)
                    1 -> CleanTab(ready, allFiles)
                    2 -> DebloatTab(ready)
                    else -> GameTab(ready)
                }
            }
        }
    }
}

/* ---------- INÍCIO ---------- */

@Composable
fun Stat(label: String, value: String, pct: Float, modifier: Modifier) {
    Panel(modifier) {
        Text(label, color = Mute, fontSize = 11.sp)
        Text(value, fontSize = 19.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { (pct / 100f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Line
        )
    }
}

@Composable
fun Home(ready: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var st by remember { mutableStateOf(readStats(ctx)) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { st = readStats(ctx); delay(2000) } }
    val ramPct = st.ramUsed * 100f / st.ramTotal
    val stoPct = st.stoUsed * 100f / st.stoTotal
    val score = (100f - ramPct * 0.35f - stoPct * 0.35f - maxOf(0f, st.temp - 35f) * 1.5f).coerceIn(0f, 100f)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Panel {
            Box(Modifier.size(190.dp).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = 22f
                    val s = Size(size.width - w, size.height - w)
                    val tl = Offset(w / 2, w / 2)
                    drawArc(color = Line, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                        topLeft = tl, size = s, style = Stroke(w, cap = StrokeCap.Round))
                    drawArc(color = Yellow, startAngle = -90f, sweepAngle = 360f * score / 100f, useCenter = false,
                        topLeft = tl, size = s, style = Stroke(w, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${score.toInt()}", fontSize = 46.sp, fontWeight = FontWeight.Light)
                    Text("SAÚDE", color = Mute, fontSize = 11.sp, letterSpacing = 3.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Btn(if (busy) "OTIMIZANDO…" else "OTIMIZAR TUDO", enabled = !busy) {
                scope.launch {
                    busy = true
                    val before = st.ramUsed
                    ctx.cacheDir.deleteRecursively()
                    val sb = StringBuilder()
                    if (ready) {
                        Shell.run("am kill-all")
                        Shell.run("pm trim-caches 999G")
                        sb.append("Processos encerrados e cache de todos os apps limpo. ")
                    } else sb.append("Shizuku inativo: só limpei o cache do AXON. ")
                    delay(1500)
                    st = readStats(ctx)
                    val freed = before - st.ramUsed
                    msg = sb.toString() + if (freed > 0) "RAM liberada: ${fmt(freed)}." else ""
                    busy = false
                }
            }
            if (msg.isNotEmpty()) { Spacer(Modifier.height(10.dp)); Text(msg, color = Cyan, fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("RAM", "${fmt(st.ramUsed)} / ${fmt(st.ramTotal)}", ramPct, Modifier.weight(1f))
            Stat("ARMAZENAMENTO", "${fmt(st.stoUsed)} / ${fmt(st.stoTotal)}", stoPct, Modifier.weight(1f))
        }
        Stat("TEMPERATURA DA BATERIA", "%.1f °C".format(st.temp), st.temp * 2f, Modifier.fillMaxWidth())
    }
}

/* ---------- LIMPEZA ---------- */

@Composable
fun CleanTab(ready: Boolean, allFiles: Boolean) {
    val scope = rememberCoroutineScope()
    var found by remember { mutableStateOf(emptyList<FileItem>()) }
    var sel by remember { mutableStateOf(emptySet<String>()) }
    var scanning by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("Todos") }
    var msg by remember { mutableStateOf("") }
    val shown = found.filter { filter == "Todos" || it.kind == filter }
    val total = found.filter { it.file.path in sel }.sumOf { it.size }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Btn(if (scanning) "ESCANEANDO…" else "ESCANEAR ARMAZENAMENTO", enabled = allFiles && !scanning) {
                scope.launch {
                    scanning = true; msg = ""
                    found = withContext(Dispatchers.IO) { Cleaner.scan() }
                    sel = found.filter { it.kind == "Temp" || it.kind == "APK" }.map { it.file.path }.toSet()
                    scanning = false
                    msg = "${found.size} itens encontrados. Temp e APK já vêm marcados; revise os demais."
                }
            }
        }
        item {
            Btn("LIMPAR CACHE DE TODOS OS APPS", ghost = true, enabled = ready) {
                scope.launch { msg = "Limpando…"; val r = Shell.run("pm trim-caches 999G"); msg = "Cache do sistema limpo. $r" }
            }
        }
        if (msg.isNotEmpty()) item { Text(msg, color = Cyan, fontSize = 13.sp) }
        if (found.isNotEmpty()) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Todos", "Temp", "APK", "Grande", "Sem uso").forEach { Chip(it, filter == it) { filter = it } }
                }
            }
            item {
                Btn("APAGAR SELECIONADOS (${fmt(total)})", enabled = sel.isNotEmpty()) {
                    scope.launch {
                        val targets = found.filter { it.file.path in sel }
                        val deleted = withContext(Dispatchers.IO) { targets.filter { it.file.delete() } }
                        found = found - deleted.toSet()
                        sel = emptySet()
                        msg = "✓ ${fmt(deleted.sumOf { it.size })} liberados (${deleted.size} arquivos)."
                    }
                }
            }
            items(shown, key = { it.file.path }) { f ->
                val toggle = { sel = if (f.file.path in sel) sel - f.file.path else sel + f.file.path }
                CheckRow(
                    f.file.name,
                    "${f.kind} · ${f.file.parent?.removePrefix("/storage/emulated/0") ?: ""}",
                    fmt(f.size), f.file.path in sel, onToggle = toggle
                )
            }
        }
    }
}

/* ---------- DEBLOAT ---------- */

@Composable
fun DebloatTab(ready: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val present = remember(tick) { Bloats.list.filter { isInstalled(ctx.packageManager, it.pkg) } }
    var sel by remember { mutableStateOf(emptySet<String>()) }
    var log by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Remover ${sel.size} apps?") },
        text = { Text("A remoção vale só para o seu usuário e é reversível em RESTAURAR. Apps marcados CUIDADO podem afetar recursos do sistema.") },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                val targets = sel.toList()
                scope.launch {
                    busy = true
                    val sb = StringBuilder()
                    targets.forEach { p ->
                        val r = Shell.run("pm uninstall -k --user 0 $p")
                        sb.appendLine("$p: ${r.ifBlank { "ok" }}")
                    }
                    log = sb.toString(); sel = emptySet(); tick++; busy = false
                }
            }) { Text("REMOVER", color = Yellow) }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("CANCELAR") } }
    )

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text("${present.size} apps removíveis encontrados neste aparelho", color = Mute, fontSize = 12.sp)
        }
        item {
            Btn("SELECIONAR OS SEGUROS", ghost = true) { sel = present.filter { it.safe }.map { it.pkg }.toSet() }
        }
        item {
            Btn(if (busy) "REMOVENDO…" else "REMOVER (${sel.size})", enabled = ready && sel.isNotEmpty() && !busy) { confirm = true }
        }
        item {
            Btn("RESTAURAR APPS REMOVIDOS", ghost = true, enabled = ready && !busy) {
                scope.launch {
                    busy = true
                    val sb = StringBuilder()
                    Bloats.list.filter { !isInstalled(ctx.packageManager, it.pkg) }.forEach {
                        sb.appendLine("${it.pkg}: ${Shell.run("cmd package install-existing ${it.pkg}").ifBlank { "ok" }}")
                    }
                    log = sb.toString().ifBlank { "Nada para restaurar." }; tick++; busy = false
                }
            }
        }
        if (log.isNotEmpty()) item { Text(log, color = Cyan, fontSize = 11.sp) }
        items(present, key = { it.pkg }) { b ->
            CheckRow(
                b.name, "${b.desc} · ${b.pkg}", "", b.pkg in sel,
                tag = if (b.safe) "SEGURO" else "CUIDADO", tagColor = if (b.safe) Green else Red,
                onToggle = { sel = if (b.pkg in sel) sel - b.pkg else sel + b.pkg }
            )
        }
    }
}

/* ---------- GAMES ---------- */

@Composable
fun GameTab(ready: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("axon", Context.MODE_PRIVATE) }
    var games by remember { mutableStateOf(prefs.getStringSet("games", emptySet())!!.toSet()) }
    var kill by remember { mutableStateOf(true) }
    var gm by remember { mutableStateOf(true) }
    var dnd by remember { mutableStateOf(true) }
    var perf by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    val apps = remember {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        ctx.packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(ctx.packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }
    val play: (String) -> Unit = { pkg ->
        scope.launch {
            val sb = StringBuilder()
            if (!ready) sb.appendLine("Shizuku inativo — abrindo sem otimizar.")
            else {
                if (kill) sb.appendLine("RAM: " + Shell.run("am kill-all").ifBlank { "ok" })
                if (gm) sb.appendLine("Modo game: " + Shell.run("cmd game mode performance $pkg").ifBlank { "ok" })
                if (dnd) sb.appendLine("Não perturbe: " + Shell.run("cmd notification set_dnd priority").ifBlank { "ok" })
                if (perf) sb.appendLine("Desempenho fixo: " + Shell.run("cmd power set-fixed-performance-mode-enabled true").ifBlank { "ok" })
            }
            log = sb.toString()
            ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(it)
            }
        }
    }
    fun toggle(pkg: String) {
        games = if (pkg in games) games - pkg else games + pkg
        prefs.edit().putStringSet("games", games).apply()
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Panel {
                Text("AO ABRIR UM JOGO", color = Mute, fontSize = 11.sp, letterSpacing = 2.sp)
                SwitchRow("Liberar RAM", "Encerra apps em segundo plano", kill) { kill = it }
                SwitchRow("Modo game do Android", "Perfil de desempenho (Android 12+)", gm) { gm = it }
                SwitchRow("Não perturbar", "Silencia notificações na partida", dnd) { dnd = it }
                SwitchRow("Desempenho fixo", "Pode esquentar e gastar bateria", perf) { perf = it }
            }
        }
        item {
            Btn("DESFAZER OTIMIZAÇÕES", ghost = true, enabled = ready) {
                scope.launch {
                    Shell.run("cmd notification set_dnd off")
                    Shell.run("cmd power set-fixed-performance-mode-enabled false")
                    games.forEach { Shell.run("cmd game mode standard $it") }
                    log = "Configurações restauradas."
                }
            }
        }
        if (log.isNotEmpty()) item { Text(log, color = Cyan, fontSize = 12.sp) }
        item { Text("MEUS JOGOS", color = Mute, fontSize = 11.sp, letterSpacing = 2.sp) }
        val mine = apps.filter { it.second in games }
        if (mine.isEmpty()) item { Text("Marque jogos na lista abaixo.", color = Mute, fontSize = 13.sp) }
        items(mine, key = { "m" + it.second }) { a ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(a.first, Modifier.weight(1f), fontSize = 15.sp)
                Button(
                    onClick = { play(a.second) },
                    colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Color.Black)
                ) { Text("▶ JOGAR", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            }
        }
        item { Text("ADICIONAR JOGOS", color = Mute, fontSize = 11.sp, letterSpacing = 2.sp) }
        items(apps, key = { "a" + it.second }) { a ->
            CheckRow(a.first, a.second, "", a.second in games, onToggle = { toggle(a.second) })
        }
    }
}
